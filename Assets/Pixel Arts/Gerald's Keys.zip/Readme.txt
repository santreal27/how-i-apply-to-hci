This is Gerald.

These are my keys.

CC0, free to use. I'd appreciate a shout-out, but it isn't necessary at all.

I did all the keys I felt like doing, so I included some blank ones in case I forgot something, or if you're using a different keyboard or special characters.

Thank you for using Gerald's keys.